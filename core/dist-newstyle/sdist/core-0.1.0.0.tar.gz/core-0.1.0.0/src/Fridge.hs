module Fridge
    where

